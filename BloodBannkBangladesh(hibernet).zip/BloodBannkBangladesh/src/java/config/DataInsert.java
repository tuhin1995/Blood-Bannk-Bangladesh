/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import BloodBank.HregisterG049605;
import BloodBank.UregisterG049605;
import java.util.ArrayList;
import java.util.List;
import net.sf.ehcache.hibernate.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Hp
 */
public class DataInsert {

    public void saveUser(UregisterG049605 usr) {
         Configuration cf =new Configaration();
        cf.configure("hibernate.cfg.xml");
          SessionFactory sf=cf.buildSessionFactory();
         Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        s.save(usr);
    }
    
      public void saveHuser(HregisterG049605 husr) {
         Configuration cf =new Configaration();
        cf.configure("hibernate.cfg.xml");
          SessionFactory sf=cf.buildSessionFactory();
         Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        s.save(husr);
    }
      
        public void saveBuser(UregisterG049605 busr) {
         Configuration cf =new Configaration();
        cf.configure("hibernate.cfg.xml");
          SessionFactory sf=cf.buildSessionFactory();
         Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        s.save(busr);
    }



  

  private static class Configaration extends Configuration {

        public Configaration() {
        }
  }
}
