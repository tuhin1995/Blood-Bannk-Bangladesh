/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import BloodBank.BregisterG049605;
import BloodBank.HregisterG049605;
import BloodBank.UregisterG049605;
import BloodBank.util;
import java.util.ArrayList;
import java.util.List;
import net.sf.ehcache.hibernate.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Hp
 */
public class Method {
    
     public void saveEmp(UregisterG049605 emp) {
        Session s = util.getSessionFactory().openSession();
        Transaction t = s.beginTransaction();
        s.save(emp);
        t.commit();
        s.close();
    }
     
       public void saveEmp1(BregisterG049605 emp1) {
        Session s = util.getSessionFactory().openSession();
        Transaction t = s.beginTransaction();
        s.save(emp1);
        t.commit();
        s.close();
    }
      public void saveEmp2(HregisterG049605 emp2) {
        Session s = util.getSessionFactory().openSession();
        Transaction t = s.beginTransaction();
        s.save(emp2);
        t.commit();
        s.close();
    }

    public void saveEmp(BregisterG049605 emp) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void saveEmp1(HregisterG049605 emp1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<BregisterG049605> getIDEmp(int id) {
        List<BregisterG049605> emplist = new ArrayList();
        Session s = util.getSessionFactory().openSession();
   //     Query q = s.createQuery("select E.bname,E.bld,E.address,E.email from BregisterG049605 E where E.address = '"+loc+"' and E.bld = '"+bld+"'");
    //    emplist = q.list();
        return emplist;
    }
  
    
}
