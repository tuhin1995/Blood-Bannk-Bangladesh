/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlar;

import BloodBank.BregisterG049605;
import BloodBank.HregisterG049605;
import BloodBank.UregisterG049605;
import BloodBank.util;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Hp
 */
public class login extends HttpServlet {

    

    private static Object getPass() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static Object getEmail() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response, Object n)
            throws ServletException, IOException {
       response.setContentType("text/html;charset=UTF-8");
         int Uid = 0;
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          String name = request.getParameter("uname");
          
           String bhu = request.getParameter("bhu");
           
           String pass = request.getParameter("pass");
        
           List<UregisterG049605> emplist = new ArrayList();
    /**       Session s = util.getSessionFactory().openSession();
        out.println("wrong user name and password !");
        if(bhu.equals("user")) 
          {
        Query q = s.createQuery("select E.uid,E.email,E.pass from UregisterG049605 E where E.email = '"+name+"' and E.pass = '"+pass+"'");
        emplist = q.list();
           List<UregisterG049605> ur = q.list();
for (UregisterG049605 a : ur) {
 a.getUid("E.uid");
    HttpSession session=request.getSession();  
           session.setAttribute("E.uname",a);
}
 */Session s = util.getSessionFactory().openSession();
        out.println("wrong user name and password !");
       s.beginTransaction();
            String hql = "select E.uid,E.email,E.pass from UregisterG049605 E where E.email = '"+name+"' and E.pass = '"+pass+"'";
              
            System.out.println(hql);
            Query query = s.createQuery(hql);
            query.setParameter(":email", login.getEmail());
            query.setParameter(":pass", login.getPass());
            List result = query.list();

            System.out.println("resultset:"+result);
    
            Iterator iterator = result.iterator();
            while(iterator.hasNext()){
                Uid = (int) iterator.next();
          
          String redirectedPage = "/parentPage";
          response.sendRedirect("welcome.jsp");
          }
        
        if(bhu.equals("b")){
            Query q1 = s.createQuery("select E.bid,E.email,E.password from BregisterG049605 E where E.email = '"+name+"' and E.password = '"+pass+"'");
        emplist = q1.list();
            
          List<BregisterG049605> br = q1.list();
for (BregisterG049605 a1 : br) {
   a1.getBid("E.bid");
     HttpSession session=request.getSession();  
     session.setAttribute("E.bname",a1);
}
        
          
          String redirectedPage = "/parentPage";
           
          response.sendRedirect("w2.jsp");
        }
         if(bhu.equals("h")){
          Query q1 = s.createQuery("select E.hid,E.email,E.pass from HregisterG049605 E where E.email = '"+name+"' and E.pass = '"+pass+"'");
        emplist = q1.list();
           
          List<HregisterG049605> hu = q1.list();
for (HregisterG049605 a2 : hu) {
   a2.getHid("E.hid");
     HttpSession session=request.getSession();  
     session.setAttribute("E.hname",a2);
}
         String redirectedPage = "/parentPage";
            
          response.sendRedirect("w1.jsp");
         }
        
        } 
        
        
        catch( Exception ex){
        System.out.println(ex);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      //  processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   //     processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
