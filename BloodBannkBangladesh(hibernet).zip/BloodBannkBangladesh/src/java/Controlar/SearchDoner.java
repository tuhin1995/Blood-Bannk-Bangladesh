/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlar;

import BloodBank.BregisterG049605;
import BloodBank.util;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Hp
 */
public class SearchDoner extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String loc = request.getParameter("loc");
            String bld = request.getParameter("bld");
            
            List<BregisterG049605> emplist = new ArrayList();
        Session s = util.getSessionFactory().openSession();
        out.println("wrong");
        Query q = s.createQuery("select E.bname,E.bld,E.address,E.email from BregisterG049605 E where E,address = '"+loc+"' and E.bld = '"+bld+"'");
        emplist = q.list();
       /**  List<Object[]> br= (List<Object[]>)q.list();
          for(Object[] user: br){
        String name = (String)user[0];
       System.out.println(name);
       String bldg = (String)user[1];
      System.out.println(bldg);
       String add=(String)user[2];
       System.out.println(add);
       String email=(String)user[3];
      System.out.println(email);

     
    }*/
          List<BregisterG049605> br = q.list();
for (BregisterG049605 a : br) {
    String name=   a.getBname("E.bname");
    String bldg =   a.getBld("E.bld");
    String add =    a.getAddress("E.address");
    String email= a.getEmail("E.email ");
   

          
          
      
           out.println(name);
           out.println(bldg);
           
           out.println(add);
           
           out.println(email);
            
}
        }
        catch(Exception ex){
        System.out.println(ex.getMessage());
        System.out.println("Error");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
